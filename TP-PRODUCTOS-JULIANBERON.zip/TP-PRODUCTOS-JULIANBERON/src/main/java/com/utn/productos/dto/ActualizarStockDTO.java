package com.utn.productos.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * DTO específico para actualizar solo el stock de un producto.
 * Usado en operaciones PATCH donde solo se modifica un campo.
 * Usa Lombok para reducir boilerplate.
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ActualizarStockDTO {

    @NotNull(message = "El stock es obligatorio")
    @Min(value = 0, message = "El stock no puede ser negativo")
    private Integer stock;
}
