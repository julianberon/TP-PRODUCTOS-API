package com.utn.productos.dto;

import com.utn.productos.model.Categoria;
import com.utn.productos.model.Producto;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * DTO para crear o actualizar un producto.
 * Usa Lombok para reducir boilerplate pero mantiene mutabilidad necesaria
 * para Bean Validation y deserialización de JSON.
 *
 * Contiene validaciones mediante Bean Validation.
 * No incluye el ID ya que este se genera automáticamente.
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ProductoDTO {

    @NotBlank(message = "El nombre es obligatorio")
    @Size(min = 3, max = 100, message = "El nombre debe tener entre 3 y 100 caracteres")
    private String nombre;

    @Size(max = 500, message = "La descripción no puede superar los 500 caracteres")
    private String descripcion;

    @NotNull(message = "El precio es obligatorio")
    @DecimalMin(value = "0.01", message = "El precio debe ser mayor a 0")
    private Double precio;

    @NotNull(message = "El stock es obligatorio")
    @Min(value = 0, message = "El stock no puede ser negativo")
    private Integer stock;

    @NotNull(message = "La categoría es obligatoria")
    private Categoria categoria;

    /**
     * Convierte este DTO a una entidad Producto.
     * Útil para operaciones de creación donde el ID aún no existe.
     *
     * @return Nueva instancia de Producto con los datos del DTO
     */
    public Producto toEntity() {
        Producto producto = new Producto();
        producto.setNombre(this.nombre);
        producto.setDescripcion(this.descripcion);
        producto.setPrecio(this.precio);
        producto.setStock(this.stock);
        producto.setCategoria(this.categoria);
        return producto;
    }

    /**
     * Actualiza una entidad Producto existente con los datos de este DTO.
     * Útil para operaciones de actualización donde se quiere preservar el ID.
     *
     * @param producto Entidad existente a actualizar
     */
    public void updateEntity(Producto producto) {
        producto.setNombre(this.nombre);
        producto.setDescripcion(this.descripcion);
        producto.setPrecio(this.precio);
        producto.setStock(this.stock);
        producto.setCategoria(this.categoria);
    }
}
