package com.utn.productos.model;

import jakarta.persistence.*;
import lombok.*;

/**
 * Entidad JPA que representa un producto en el sistema.
 * Esta clase se mapea a la tabla "productos" en la base de datos.
 * Usa Lombok para reducir código boilerplate (getters, setters, constructores, etc.)
 */
@Entity
@Table(name = "productos")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Producto {

    /**
     * Identificador único del producto.
     * Generado automáticamente por la base de datos.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * Nombre descriptivo del producto.
     */
    @Column(nullable = false, length = 100)
    private String nombre;

    /**
     * Descripción detallada del producto.
     */
    @Column(length = 500)
    private String descripcion;

    /**
     * Precio unitario del producto en la moneda local.
     */
    @Column(nullable = false)
    private Double precio;

    /**
     * Cantidad disponible en inventario.
     */
    @Column(nullable = false)
    private Integer stock;

    /**
     * Categoría a la que pertenece el producto.
     * Se persiste como String en la base de datos.
     */
    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private Categoria categoria;

    /**
     * Constructor sin ID para facilitar la creación de nuevos productos.
     * El ID se genera automáticamente al persistir.
     *
     * @param nombre Nombre del producto
     * @param descripcion Descripción del producto
     * @param precio Precio unitario
     * @param stock Cantidad en inventario
     * @param categoria Categoría del producto
     */
    public Producto(String nombre, String descripcion, Double precio, Integer stock, Categoria categoria) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.precio = precio;
        this.stock = stock;
        this.categoria = categoria;
    }
}
