package com.utn.productos.repository;

import com.utn.productos.model.Categoria;
import com.utn.productos.model.Producto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Repositorio JPA para la entidad Producto.
 * Extiende JpaRepository que proporciona métodos CRUD básicos y query methods.
 *
 * JpaRepository<Producto, Long> indica:
 * - Producto: la entidad que gestiona
 * - Long: el tipo de dato de la clave primaria
 *
 * Spring Data JPA genera automáticamente la implementación en tiempo de ejecución.
 */
@Repository
public interface ProductoRepository extends JpaRepository<Producto, Long> {

    /**
     * Método de consulta personalizado para buscar productos por categoría.
     * Spring Data JPA genera automáticamente la consulta SQL basándose en el nombre del método.
     *
     * Equivale a: SELECT * FROM productos WHERE categoria = ?
     *
     * @param categoria La categoría por la cual filtrar
     * @return Lista de productos que pertenecen a la categoría especificada
     */
    List<Producto> findByCategoria(Categoria categoria);
}
